//Numpy array shape [4, 1]
//Min 0.109375000000
//Max 0.808593750000
//Number of zeros 0

#ifndef W14_H_
#define W14_H_

#ifndef __SYNTHESIS__
weight14_t w14[4];
#else
weight14_t w14[4] = {0.11328125, 0.25390625, 0.10937500, 0.80859375};
#endif

#endif
