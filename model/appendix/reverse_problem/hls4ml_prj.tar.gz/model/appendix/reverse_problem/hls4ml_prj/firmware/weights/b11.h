//Numpy array shape [4]
//Min -0.800781250000
//Max 0.000000000000
//Number of zeros 1

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
bias11_t b11[4];
#else
bias11_t b11[4] = {-0.51562500, -0.60156250, -0.80078125, 0.00000000};
#endif

#endif
