//Numpy array shape [8]
//Min -0.943603515625
//Max 0.085449218750
//Number of zeros 2

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[8];
#else
bias5_t b5[8] = {-0.9436035156250, -0.1571655273438, 0.0854492187500, -0.0787963867188, -0.2872924804688, -0.1971435546875, 0.0000000000000, 0.0000000000000};
#endif

#endif
