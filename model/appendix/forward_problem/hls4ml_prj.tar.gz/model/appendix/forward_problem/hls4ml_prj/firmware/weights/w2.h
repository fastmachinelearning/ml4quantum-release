//Numpy array shape [1, 4]
//Min -0.951660156250
//Max 0.904174804688
//Number of zeros 0

#ifndef W2_H_
#define W2_H_

#ifndef __SYNTHESIS__
weight2_t w2[4];
#else
weight2_t w2[4] = {0.3368530273438, 0.3905639648438, -0.9516601562500, 0.9041748046875};
#endif

#endif
