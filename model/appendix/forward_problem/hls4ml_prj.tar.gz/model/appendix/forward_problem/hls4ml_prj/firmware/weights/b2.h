//Numpy array shape [4]
//Min -0.938110351562
//Max 0.209777832031
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[4];
#else
bias2_t b2[4] = {-0.5885009765625, 0.2097778320312, -0.9381103515625, -0.3839721679688};
#endif

#endif
